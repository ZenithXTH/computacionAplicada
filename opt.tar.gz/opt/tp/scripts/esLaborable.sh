#!/bin/bash

 function esLaborable(){
    
    echo "ingrese una fecha DD/MM:"
    read FECHA
    
    case "$FECHA" in
        01/01) echo "Es Feriado Nacional por: Año Nuevo.";;
        24/03) echo "Es Feriado Nacional por: Día Nacional de la Memoria por la Verdad y la Justicia.";;
        02/04) echo "ES Feriado Nacional por: Día del Veterano y de los Caídos en la Guerra de Malvinas.";;
        01/05) echo "ES Feriado Nacional por: Día del Trabajo.";;
        25/05) echo "ES Feriado Nacional por: Día de la Revolución de Mayo.";;
        20/06) echo "ES Feriado Nacional por: Paso a la Inmortalidad del General D. Manuel Belgrano.";;
        09/07) echo "ES Feriado Nacional por: Día de la Independencia.";;
        17/08) echo "ES Feriado Nacional por: Paso a la Inmortalidad del General D. José de San Martín.";;
        12/10) echo "ES Feriado Nacional por: Día del Respeto a la Diversidad Cultural.";;
        20/11) echo "ES Feriado Nacional por: Día de la Soberanía Nacional.";;
        8/12) echo "ES Feriado Nacional por: Día de la Inmaculada Concepción de María.";;
        25/12) echo "ES Feriado Nacional por: Navidad";;
        *) echo "Es Dia Laborable"
    esac   
}


esLaborable

exit 1
