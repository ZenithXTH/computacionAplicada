#!/bin/bash

proceso=$1

pidof $proceso

if [ $? = 1 ]; then
	echo "EL programa $proceso no se esta ejecutando" | mutt -s 'informe' root@localhost.com
fi

exit 0
