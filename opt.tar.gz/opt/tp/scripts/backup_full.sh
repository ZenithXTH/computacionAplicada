#!/bin/bash

#script que genera un respaldo
#COMMENTS:
# Se dejaron algunos echo intencionalmente que corroboran funcionamiento normal.
# Una mejora podria ser mover las funciones a otro archivo.

#)1 MANEJO DE ARGS

# Sin args
[ $# -eq 0 ] && { echo "Uso: -h para ayuda o $0 origen destino"; exit 1; }

# Ayuda 
ORIGEN=$1
DESTINO=$2

if [ "$ORIGEN" == "-h" ]; then
	echo ayuda
	exit 0
fi


#########################################################

#)2 VALIDACION

## validar fs de origen y destino (existencia y mounted)
#EXISTENCIA

existe () {

	if [ -d $1 ]; then
		return 0
	else 
		echo $1 NO EXISTE
		exit 1 
	fi	
}

existe $ORIGEN 
existe $DESTINO

# Mounted? 

isMounted () {
# usa el exit estatus de grep para saber si $1 esta montado
	if mount | grep $1 > /dev/null; then 
		return 0
	else 
		echo "$1" No montado
		exit 1
	fi
} 

isMounted $DESTINO

#########################################################
#)3 SAVE 

## guardar archivos de back up en DESNTINO

STAMP=$(date +'%4Y%m%d')

END_DESTINO=$DESTINO/${ORIGEN///}_bkp_$STAMP.tar.gz
echo $END_DESTINO
echo $ORIGEN

tar -cpzf $END_DESTINO $ORIGEN

#########################################################

#)4 LOG

##(funcion )generar log: 
##"HH:MM:SS - <Que estoy haciendo> | <Que esta pasando:

function log () { 
	FILE="info-log.txt"
	echo $1 > $FILE # usamo solo '>' para limpiar el archivo
	date +'%X' | tee -a $FILE
	echo LOG GREATED
}

log BACK_UP_"$ORIGEN"

## MAIL
cat $FILE | mutt -s "AUTO_BACKUP"  root@localhost.com
echo $FILE

exit 0
##########################################################
